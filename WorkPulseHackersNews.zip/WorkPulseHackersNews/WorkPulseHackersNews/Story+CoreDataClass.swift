//
//  Story+CoreDataClass.swift
//  WorkPulseHackersNews
//
//  Created by Pramod Parihar on 27/08/18.
//  Copyright © 2018 Pramod Parihar. All rights reserved.
//
//

import Foundation
import CoreData


public class Story: NSManagedObject {

}
