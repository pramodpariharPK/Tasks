//
//  ViewController.swift
//  WorkPulseHackersNews
//
//  Created by Pramod Parihar on 27/08/18.
//  Copyright © 2018 Pramod Parihar. All rights reserved.
//

import UIKit
import CoreData
import MBProgressHUD

let storiesIDUrl = "https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty"
let storyBaseUrl = "https://hacker-news.firebaseio.com/v0/item/"

class ViewController: UIViewController {

    @IBOutlet weak var tblHome: UITableView!
    var hnStoryIds = [Int]()
    let storiesInAPage = 30
    var storyListArr = [[String: AnyObject]]()
   
    //Pagination
    private var currentPage = 1
    private var shouldShowLoadingCell = true
    
    // PullDown to refresh Table List
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:
            #selector(ViewController.handleRefresh(_:)),
                                 for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.red
        
        return refreshControl
    }()
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        self.loadStoryIds()

        refreshControl.endRefreshing()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tblHome.addSubview(self.refreshControl)
        self.tblHome.estimatedRowHeight = 63.0
        var saveDataCount = 0
        do {
            try self.fetchedhResultController.performFetch()
            saveDataCount = (self.fetchedhResultController.sections?[0].numberOfObjects)!
            print("COUNT FETCHED FIRST: \(saveDataCount)")
        } catch let error  {
            print("ERROR: \(error)")
        }
        if saveDataCount == 0 {
            self.loadStoryIds()
        }
    }
    @IBAction func refreshHackersNews(_ sender: Any) {
        self.tblHome.reloadData()
    }
    private func clearData() {
        do {
            let context = HNCoreDataStack.sharedInstance.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Story")
            do {
                let objects  = try context.fetch(fetchRequest) as? [NSManagedObject]
                _ = objects.map{$0.map{context.delete($0)}}
                HNCoreDataStack.sharedInstance.saveContext()
            } catch let error {
                print("ERROR DELETING : \(error)")
            }
        }
    }
    func refresTable(){
        self.storyListArr.removeAll()
        self.tblHome.reloadData()
    }
    //MARK:- Server Request
    func loadStoryIds() {
        currentPage = 1

        MBProgressHUD.showAdded(to: self.view, animated: true)
        refresTable()
        let service = HackersAPIService()
        service.getStoriesIds { (idsArr, error) in
            self.hnStoryIds = idsArr
            print(self.hnStoryIds)
            self.fetchStoriesUsing(ids: self.hnStoryIds)
            MBProgressHUD.hide(for: self.view, animated: true)

        }
    }
    func fetchStoriesUsing(ids: [Int]) {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        var downloadedCount: Int = 0
        for i in 0...self.storiesInAPage {
            let service = HackersAPIService()
            service.getStoryItem(id: ids[i]) { (dictionaryObj, error) in
                self.storyListArr.append(dictionaryObj)
                downloadedCount += 1
                if downloadedCount >= self.storiesInAPage{
                    self.clearData()
                    self.saveInCoreDataWith(array: self.storyListArr)
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(self.storyListArr)
                    DispatchQueue.main.async {
                        self.tblHome.reloadData()
                    }
                }
            }
        }
    }
    func fetchStoriesForPagination(ids: [Int])
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        var downloadedCount: Int = 0
        for i in 0...self.storiesInAPage {
            let service = HackersAPIService()
            service.getStoryItem(id: ids[i]) { (dictionaryObj, error) in
                self.storyListArr.append(dictionaryObj)
                downloadedCount += 1
                if downloadedCount >= self.storiesInAPage{
                    self.clearData()
                    self.saveInCoreDataWith(array: self.storyListArr)
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(self.storyListArr)
                    DispatchQueue.main.async {
                        self.tblHome.reloadData()
                    }
                }
            }
        }
    }
    func loadDataForPagination(){
        var downloadedCount: Int = 0

        let startIndex = ((currentPage - 1) * storiesInAPage) + 1
        let lastIndex = currentPage * storiesInAPage
        for i in startIndex...lastIndex{
            let service = HackersAPIService()
            service.getStoryItem(id: self.hnStoryIds[i]) { (dictionaryObj, error) in
                self.storyListArr.append(dictionaryObj)
                downloadedCount += 1
                if downloadedCount >= self.storiesInAPage{
                    self.saveInCoreDataWith(array: self.storyListArr)
                    MBProgressHUD.hide(for: self.view, animated: true)
                    self.shouldShowLoadingCell = self.currentPage < ((self.hnStoryIds.count/self.storiesInAPage) + (self.hnStoryIds.count%self.storiesInAPage))
                    print(self.storyListArr)
                    DispatchQueue.main.async {
                        self.tblHome.reloadData()
                    }
                }
            }
        }
    }
    //MARK:- CoreData Save
    /*
     for dict in array {
     _ = self.createPhotoEntityFrom(dictionary: dict)
     }
     */
    private func saveInCoreDataWith(array: [[String: AnyObject]]) {
        _ = array.map{self.createPhotoEntityFrom(dictionary: $0)}
        do {
            try HNCoreDataStack.sharedInstance.persistentContainer.viewContext.save()
        } catch let error {
            print(error)
        }
    }
    private func createPhotoEntityFrom(dictionary: [String: AnyObject]) -> NSManagedObject? {
        let context = HNCoreDataStack.sharedInstance.persistentContainer.viewContext
        if let storyEntity = NSEntityDescription.insertNewObject(forEntityName: String(describing: Story.self), into: context) as? Story {
            storyEntity.id = Int64(String(format: "%@", (dictionary["id"] as? NSNumber)!))!
            storyEntity.title = dictionary["title"] as? String
            storyEntity.score = Int32(String(format: "%@", (dictionary["score"] as? NSNumber)!))!
//            storyEntity.by = dictionary["by"] as? String
//            storyEntity.type = dictionary["type"] as? String
//            storyEntity.url = dictionary["url"] as? String

            return storyEntity
        }
        return nil
    }
    //MARK:- CoreData Fetch
    lazy var fetchedhResultController: NSFetchedResultsController<NSFetchRequestResult> = {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: String(describing: Story.self))
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "score", ascending: false)]
        let frc = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: HNCoreDataStack.sharedInstance.persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
         frc.delegate = self
        return frc
    }()
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        guard isLoadingIndexPath(indexPath) else { return }
        loadDataForPagination()
    }
    
    private func isLoadingIndexPath(_ indexPath: IndexPath) -> Bool {
        guard shouldShowLoadingCell else { return false }
        if let count = self.fetchedhResultController.sections?.first?.numberOfObjects {
            return indexPath.row == count
        }
        return false
    }
}
extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.fetchedhResultController.sections?.first?.numberOfObjects {
            return shouldShowLoadingCell ? count + 1 : count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if isLoadingIndexPath(indexPath) {
            return LoadingCell(style: .default, reuseIdentifier: "loading")
        } else {
            
            let cell : HomeCell = tableView.dequeueReusableCell(withIdentifier: "homeCell") as! HomeCell
            if let story = self.fetchedhResultController.object(at: indexPath) as? Story {
                cell.lblTitle.text = story.title
                cell.lblScore.text = String(story.score)
            }
            
            return cell
            
        }
    }
    
    
}

extension ViewController: NSFetchedResultsControllerDelegate {
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            self.tblHome.insertRows(at: [newIndexPath!], with: .automatic)
        case .delete:
            self.tblHome.deleteRows(at: [indexPath!], with: .automatic)
        default:
            break
        }
    }
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblHome.endUpdates()
    }
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblHome.beginUpdates()
    }
}
