//
//  Story+CoreDataProperties.swift
//  WorkPulseHackersNews
//
//  Created by Pramod Parihar on 27/08/18.
//  Copyright © 2018 Pramod Parihar. All rights reserved.
//
//

import Foundation
import CoreData


extension Story {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Story> {
        return NSFetchRequest<Story>(entityName: "Story")
    }

    @NSManaged public var id: Int64
    @NSManaged public var title: String?
    @NSManaged public var score: Int32
    @NSManaged public var isRead: Bool
    @NSManaged public var type: String?
    @NSManaged public var url: String?
    @NSManaged public var by: String?

}
