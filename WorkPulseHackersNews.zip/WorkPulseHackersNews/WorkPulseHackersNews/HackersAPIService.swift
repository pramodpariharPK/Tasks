//
//  HackersAPIService.swift
//  WorkPulseHackersNews
//
//  Created by Pramod Parihar on 27/08/18.
//  Copyright © 2018 Pramod Parihar. All rights reserved.
//

import UIKit


class HackersAPIService: NSObject {
    
    
    /// Fetch top stories Ids
    func getStoriesIds(_ completion: @escaping (_ ids: [Int], _ error: Error?) -> Void) {
        guard let url = URL(string: storiesIDUrl) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard error == nil else { return }
            guard let data = data else { return }
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: [.mutableContainers]) as? [Int] {
                    DispatchQueue.main.async {
                        completion(json, error)
                    }
                }
            } catch let error {
                print(error)
            }
            }.resume()
    }
    /// Fetch a story
    func getStoryItem(id: Int, _ completion: @escaping (_ item: [String: AnyObject], _ error: Error?) -> Void) {
        let storyId = "\(id).json?print=pretty"
        guard let url = URL(string: storyBaseUrl+storyId) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard error == nil else { return }
            guard let data = data else { return }
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: [.mutableContainers]) as? [String: AnyObject]{
                    DispatchQueue.main.async {
                        completion(json, error)
                    }
                }
            } catch let error {
                print(error)
            }
            }.resume()
    }

}
